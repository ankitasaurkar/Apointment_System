package com.apoint;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class ServiceClass implements UserDetailsService
{
	@Autowired
    private ClassInterface userRepoS;
	
	@Override
	 public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException 
	 {
	        EntityClass userS = userRepoS.findByEmail(username);
	        if (userS == null) 
	        {
	            throw new UsernameNotFoundException("User not found");
	        }
			return null;
	      
	    }
}
