package com.apoint;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "mytable")
public class EntityClass
{
	
    @Column(nullable = false,length = 100)
	private String hName;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    
    
    @Column(nullable = false,length = 50)
	private String pName;
    
    @Column(nullable = false,unique = true,length = 50)
	private String email;
    
    @Column(nullable = false,length = 50)
	private String pAddress;
    
    @Column(nullable=false,length=11)
	private String pAge;
    
    @Column(nullable = false,length = 50)
	private String pGender;
    
    @Column(nullable = false,length = 64)
	private String pContact;
    
    @Column(nullable=false,length = 30)
	private String aDate;
    
    @Column(nullable=false,length = 30)
	private String aTime;
	
    @Column(nullable = false,length = 50)
	private String aDName;
}

