package com.apoint;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;








@Controller
public class ControllerClass
{
	@Autowired
    private ClassInterface userRepoS;
	

	@GetMapping("/index")
	public String goHome() 
	{
		return "index";
	}
	 @GetMapping("/register")
	    public String showRegistrationForm(Model model)
	  {
	        model.addAttribute("userS",new EntityClass());
	        return "appo1";
	    }

        @PostMapping("/sucessForm")
        public String saveUserForm(EntityClass userS)
        {
			userRepoS.save(userS);
			return "sucessForm";
        	
        }
	    
	   @GetMapping("/list_form")
	    public String listUsers(Model model) 
	    {
	        List<EntityClass> listUsers = userRepoS.findAll();
	        model.addAttribute("listUsers", listUsers);
	        return "list_form";
	    }
}
