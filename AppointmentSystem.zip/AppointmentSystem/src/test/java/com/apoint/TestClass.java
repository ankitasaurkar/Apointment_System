package com.apoint;


import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;





@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class TestClass
{
    @Autowired
    private TestEntityManager entityManager;
    
    
    @Autowired
    private ClassInterface repo;
    
    
    @Test
    public void testCreateUser() throws IOException 
    {
    	EntityClass userS = new EntityClass();
	        userS.setHName("Appolo Hospial");
	        userS.setPName("pratik ganjare");
	        userS.setEmail("pratikganjare@gmail.com");
	        userS.setPAddress("Wadali");
	        userS.setPAge("77");
	        userS.setPGender("Male");
	        userS.setPContact("8087178207");
	        userS.setADate("5-7-2021");
	        userS.setATime("12:3 pm");
	        userS.setADName(" Dr. Akshay Kumar");
        EntityClass savedUser = repo.save(userS);
        EntityClass existUser = entityManager.find(EntityClass.class,savedUser.getId());
        assertThat(userS.getEmail()).isEqualTo(existUser.getEmail());
         
    }


}
