package com.apoint;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface ClassInterface extends JpaRepository<EntityClass,Long>

{

	@Query("SELECT u FROM EntityClass u WHERE u.email = ?1")
    public EntityClass findByEmail(String email);

}
